package com.fiap.funtoy;

import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name="TDS_TB_Brinquedos")
public class Brinquedos implements Serializable {

    @Id
    @Column(name="B_ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="B_NOME", nullable = false, length = 100)
    private String nome;

    @Column(name="B_TIPO", nullable = false, length = 50)
    private String tipo;

    @Column(name="B_CLASSIFICACAO", nullable = false, length = 50)
    private String classificacao;

    @Column(name="B_TAMANHO", nullable = false, length = 100)
    private String tamanho;

    @Column(name="B_PRECO", nullable = false, length = 10)
    private double preco;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getClassificacao() {
        return classificacao;
    }

    public void setClassificacao(String classificacao) {
        this.classificacao = classificacao;
    }

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }
}
