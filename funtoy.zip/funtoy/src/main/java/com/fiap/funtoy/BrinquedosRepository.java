package com.fiap.funtoy;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BrinquedosRepository extends CrudRepository <Brinquedos, Long> {
}
