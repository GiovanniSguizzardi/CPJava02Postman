package com.fiap.funtoy;

import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@RestController
public class RestcrudController {

    private List<Brinquedos> brinquedos = new ArrayList<>();

    // Método para LISTAR os brinquedos
    @GetMapping("/brinquedos")
    public List<Brinquedos> listarBrinquedos() {
        return brinquedos;
    }

    // Método para CRIAR um brinquedo novo
    @PostMapping("/brinquedos/add")
    public Brinquedos criarBrinquedo(@RequestBody Brinquedos brinquedo) {
        brinquedo.setId( generateNextId() );
        brinquedos.add(brinquedo);
        return brinquedo;
    }

    // Método para ATUALIZAR algum brinquedo
    @PutMapping("/brinquedos/atualizar/{id}")
    public Brinquedos atualizarBrinquedo(@PathVariable Long id, @RequestBody Brinquedos brinquedo) {
        Brinquedos brinquedoExistente = brinquedos.stream()
                .filter(u -> u.getId().equals(id))
                .findFirst()
                .orElseThrow( () -> new IllegalArgumentException("Brinquedo não encontrado no método: atualizarBrinquedo"));

        brinquedoExistente.setNome(brinquedo.getNome());
        brinquedoExistente.setTipo(brinquedo.getTipo());

        return brinquedoExistente;
    }

    // Método para DELETAR um brinquedo
    @DeleteMapping("/brinquedos/delete/{id}")
    public void excluirBrinquedo(@PathVariable Long id) {
        brinquedos.removeIf( u -> u.getId().equals(id));
    }


    // Método para listar um Brinquedo por ID especifico
    @GetMapping("/brinquedos/buscarid/{id}")
    public Brinquedos buscarBrinquedoPorId(@PathVariable Long id) {
        return brinquedos.stream()
                .filter(u -> u.getId().equals(id))
                .findFirst()
                .orElseThrow( () -> new IllegalArgumentException("Brinquedo não encontrado no método: buscarBrinquedoPorId"));
    }

    private Long generateNextId() {
        Long maxId = brinquedos.stream()
                .mapToLong(Brinquedos::getId)
                .max()
                .orElse(0L);
        return maxId + 1;
    }
}
